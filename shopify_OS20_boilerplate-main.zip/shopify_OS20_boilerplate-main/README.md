# Shopify Online Store 2.0 - Boilerplate
### FREE - Basic template to start the development of a Shopify Online Store 2.0 theme with all the necessary

![Shopify](https://i.ibb.co/85CkkDW/Estudio-de-Fotografi-a-Portada-de-Facebook.png)