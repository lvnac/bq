#Features to do and already done

- Basic Page ✅
- 404 Page ✅
- Blog Page ✅
- Article Page ✅
- Cart Page ✅
- Collection List Page ✅
- Collection Page ✅
- Home Page (Index) ✅
- Contact Page ✅
- Product Page ✅
- Search Funtionality (Header) ✅
- Search Result Page ✅
- Gift Card Page